import streamlit as st,pandas as pd,matplotlib.pyplot as plt
from agri_insights.pipeline import train
st.set_page_config(page_title='Agri Insights',page_icon='⌁',layout='wide')
st.markdown("<style>.stApp{background:#f2f4ed}.stMetric{background:#e3eadc;padding:12px;border-radius:8px}h1,h2{color:#314e38}</style>",unsafe_allow_html=True)
st.title('Agri Insights');st.caption('Field performance · model evaluation workbench')
st.warning('Use a documented field-performance target. This tool does not assume that an arbitrary crop-yield column is equivalent to your resume project label.')
f=st.file_uploader('Upload a CSV dataset',type=['csv'])
if f:
 d=pd.read_csv(f);st.subheader('Dataset profile');c1,c2,c3=st.columns(3);c1.metric('Rows',f'{len(d):,}');c2.metric('Columns',d.shape[1]);c3.metric('Missing cells',f'{int(d.isna().sum().sum()):,}')
 st.dataframe(d.head(20),use_container_width=True)
 target=st.selectbox('Target label',d.columns);algo=st.selectbox('Model', ['random_forest','extra_trees','logistic','xgboost'])
 if st.button('Train and evaluate',type='primary'):
  try:
   with st.spinner('Fitting preprocessing and evaluating holdout…'):r=train(d,target,algo)
   st.session_state['agri_result']=(r,d)
  except Exception as e:st.error(str(e))
if 'agri_result' in st.session_state:
 r,d=st.session_state['agri_result'];m=r.metrics
 a,b,c=st.columns(3);a.metric('Balanced accuracy',f"{m['balanced_accuracy']:.3f}");b.metric('Macro F1',f"{m['macro_f1']:.3f}");c.metric('Test rows',m['test_rows'])
 st.json(m);fig,ax=plt.subplots();ax.imshow(r.confusion);ax.set_title('Confusion matrix');ax.set_xlabel('Predicted');ax.set_ylabel('Actual');ax.set_xticks(range(len(r.labels)),r.labels,rotation=45,ha='right');ax.set_yticks(range(len(r.labels)),r.labels);st.pyplot(fig)
 st.caption('These values describe this uploaded dataset and holdout only. They are not field-level guarantees or externally validated performance.')
