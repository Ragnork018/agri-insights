# Agricultural data sources and target definition

The resume does not identify the original data source or class definition for “field performance”. Obtain the original CSV, data dictionary, label-generation method, crop/location/time scope, and license before claiming equivalence to the earlier project.

Potential research sources: [FAO/IIASA GAEZ v4](https://www.fao.org/gaez/gaezv4/en) includes crop suitability and attainable yield layers; [NASA POWER](https://power.larc.nasa.gov/) supplies agroclimatology/weather variables; [ISRIC SoilGrids](https://soilgrids.org/) supplies mapped soil property estimates. These are not ready-made labelled field-performance records. Merging them requires a spatial/temporal join and independent ground truth.
