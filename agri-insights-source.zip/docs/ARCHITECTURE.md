# Architecture

```mermaid
flowchart LR
  CSV[User dataset] --> Validate[Schema + label validation]
  Validate --> Split[Stratified holdout]
  Split --> Prep[Train-fold imputation + encoding + scaling]
  Prep --> Model[RF / ExtraTrees / Logistic / optional XGBoost]
  Model --> Evaluate[Balanced accuracy + macro F1 + confusion matrix]
  Evaluate --> Artifact[Model + metrics + card]
```

No domain schema is assumed until the original target and label definition are supplied.
