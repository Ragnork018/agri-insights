# Agri Insights — field performance modelling workbench

A reproducible classification pipeline for agricultural field-performance datasets. It validates tabular data, handles numeric/categorical missing values inside the training pipeline, uses a stratified holdout, supports balanced random forest, Extra Trees, and logistic-regression estimators, and exports metrics and a fitted model.

## Critical dataset requirement

The resume does not name the original dataset, its target column, class meanings, location/time coverage, or label-generation process. This repository therefore does not claim to predict crop yield or recommend agronomic actions. Supply the actual field-performance dataset and data dictionary before interpreting model outputs; see [`docs/DATASETS.md`](docs/DATASETS.md). See [`docs/DATASETS.md`](docs/DATASETS.md).

## Run

```bash
pip install -e '.[dev,dashboard]'
python -m agri_insights.train --csv /path/to/fields.csv --target performance_class --out artifacts
streamlit run dashboard.py
pytest
```

Target must contain at least two classes. The holdout is stratified; preprocessing is fitted only on training folds. Do not use columns generated after the outcome or derived from the label.

## Reports

`metrics.json`, `classification_report.json`, `confusion_matrix.csv`, and `model.joblib` are written to the output folder. These are valid only for the supplied dataset and split.
